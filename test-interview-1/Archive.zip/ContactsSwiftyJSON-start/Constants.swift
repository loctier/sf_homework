//
//  Constants.swift
//  ContactsSwiftyJSON-start
//
//  Created by Denis Loctier on 23/12/2022.
//

import Foundation

let initialURL = "https://finalspaceapi.com/"

let apiURL = initialURL + "api/v0/character/?limit=7"

typealias GetComplete = () ->()


